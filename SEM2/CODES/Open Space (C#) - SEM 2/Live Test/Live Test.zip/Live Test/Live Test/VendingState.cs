﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Live_Test
{
    //state enums
    public enum VendingState
    {
        INIT,
        SELECT,
        PREPARE,
        END
    }
}
