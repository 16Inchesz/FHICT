﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoloClubApp
{
    interface IWearable
    {
        // returns the int value for waterResistanceMeters private field
        int GetWaterResistanceMeters();
    }
}
