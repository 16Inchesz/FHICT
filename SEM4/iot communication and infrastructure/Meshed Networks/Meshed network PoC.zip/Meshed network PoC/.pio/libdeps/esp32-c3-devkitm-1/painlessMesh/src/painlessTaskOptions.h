//  The following two complie options are required for painlessMesh
#define _TASK_PRIORITY      // Support for layered scheduling priority
#define _TASK_STD_FUNCTION  // Support for std::function (ESP8266 and ESP32
                            // ONLY)
